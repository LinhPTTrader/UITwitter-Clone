export const ALERTTYPE = {
    LOGOUT_SUCCESS: 'Logout Success'
}